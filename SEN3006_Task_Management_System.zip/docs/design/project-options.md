# SEN3006 - Project Topic Options

> **Constraints:** Pure Java (zero external dependencies), at least 2 design patterns from different categories, console-based (System.out.println), executable via Main.java.

## Scoring Criteria

Each option is rated on a 5-point scale across these dimensions:

| Criteria | What It Means |
|---|---|
| Ease of Implementation | How simple is the code? Fewer classes = easier |
| Ease of Explanation | Can you explain it in 2 minutes to the professor? |
| Pattern Fit | Do the design patterns feel natural, not forced? |
| Mandatory UML Coverage | How cleanly does it map to Class, Sequence, and Use Case diagrams? |
| Optional UML Coverage | Does it naturally support Activity, State, Component, or Deployment diagrams? |
| Editability | How easy is it to swap the topic/domain later without rewriting patterns? |
| Creativity Points | Will it stand out from other groups? |

---

## Option 1: Order Processing System

**Domain:** A restaurant/cafe takes orders of different types (dine-in, takeaway, delivery) and applies different discount strategies.

**Patterns:**
- **Factory Method** (Creational) — `OrderFactory` creates `DineInOrder`, `TakeAwayOrder`, `DeliveryOrder`
- **Strategy** (Behavioral) — `DiscountStrategy` interface with `NoDiscount`, `PercentageDiscount`, `FlatDiscount`

**Why it works:** Everyone understands ordering food. The Factory Method naturally creates different order types, and Strategy naturally swaps pricing logic. No forced patterns.

**Class count:** ~10 (2 interfaces, 3 factory subclasses, 3 order types, 3 strategies, 1 Main)

| Criteria | Score | Notes |
|---|---|---|
| Ease of Implementation | ★★★★★ | Simplest option, minimal logic |
| Ease of Explanation | ★★★★★ | Universal concept, no domain knowledge needed |
| Pattern Fit | ★★★★★ | Both patterns are textbook-perfect for this domain |
| Mandatory UML Coverage | ★★★★★ | Clean class hierarchy, clear sequence flow, obvious use cases |
| Optional UML Coverage | ★★★☆☆ | Activity diagram fits (order flow). State diagram is a stretch. No component/deployment. |
| Editability | ★★★★★ | Swap "restaurant" for any domain — patterns stay identical |
| Creativity Points | ★★☆☆☆ | Common topic, many groups will pick similar |

**Optional diagrams it supports:**
- ✅ Activity Diagram — order placement workflow (select type → add items → apply discount → confirm)
- ⚠️ State Diagram — weak fit, orders don't have rich state transitions
- ❌ Component Diagram — too simple for modular breakdown
- ❌ Deployment Diagram — not applicable (single console app)

---

## Option 2: Vehicle Fleet Management System

**Domain:** A company manages a fleet of vehicles (Car, Truck, Motorcycle). Different vehicles have different fuel calculation strategies. A central fleet manager coordinates everything.

**Patterns:**
- **Factory Method** (Creational) — `VehicleFactory` creates `Car`, `Truck`, `Motorcycle`
- **Strategy** (Behavioral) — `FuelCalculationStrategy` with `StandardFuel`, `HeavyDutyFuel`, `EcoFuel`

**Why it works:** Vehicles are concrete and visual — easy to draw in UML, easy to explain. Each vehicle type behaves differently, which justifies the Strategy pattern. The fleet manager adds a natural coordinator class.

**Class count:** ~12 (2 interfaces, 3 factories, 3 vehicles, 3 strategies, 1 FleetManager, 1 Main)

| Criteria | Score | Notes |
|---|---|---|
| Ease of Implementation | ★★★★☆ | Slightly more classes, but still straightforward |
| Ease of Explanation | ★★★★★ | Cars and trucks — everyone gets it |
| Pattern Fit | ★★★★★ | Factory for vehicle types, Strategy for fuel — both natural |
| Mandatory UML Coverage | ★★★★★ | Rich class diagram with clear inheritance, good sequence flow |
| Optional UML Coverage | ★★★★☆ | State diagram fits well (vehicle states: available → in-use → maintenance → retired) |
| Editability | ★★★★☆ | Domain is specific but patterns are swappable |
| Creativity Points | ★★★☆☆ | Less common than restaurant/order systems |

**Optional diagrams it supports:**
- ✅ Activity Diagram — vehicle assignment workflow (check availability → assign → track fuel → return)
- ✅ State Diagram — vehicle lifecycle (Available → InUse → Maintenance → Retired)
- ⚠️ Component Diagram — could separate VehicleModule and FuelModule, but feels forced
- ❌ Deployment Diagram — not applicable

---

## Option 3: Task Management System

**Domain:** A project manager creates tasks of different types (Bug, Feature, Documentation). Tasks are executed using different priority strategies. Tasks have clear lifecycle states.

**Patterns:**
- **Factory Method** (Creational) — `TaskFactory` creates `BugTask`, `FeatureTask`, `DocumentationTask`
- **Strategy** (Behavioral) — `PriorityStrategy` with `UrgentFirst`, `DeadlineFirst`, `SeverityFirst`

**Why it works:** Software-related domain that the professor will appreciate (meta — using design patterns to build a system about managing software). Tasks have natural states, making State diagrams relevant.

**Class count:** ~12 (2 interfaces, 3 factories, 3 task types, 3 strategies, 1 TaskManager, 1 Main)

| Criteria | Score | Notes |
|---|---|---|
| Ease of Implementation | ★★★★☆ | Slightly more logic for task state management |
| Ease of Explanation | ★★★★★ | Professor works with tasks daily — relatable |
| Pattern Fit | ★★★★★ | Factory for task types, Strategy for prioritization — both natural |
| Mandatory UML Coverage | ★★★★★ | Clean class diagram, clear sequence, obvious use cases (create, assign, complete) |
| Optional UML Coverage | ★★★★★ | All optional diagrams fit naturally |
| Editability | ★★★★☆ | Domain-specific but patterns are clean and isolated |
| Creativity Points | ★★★★☆ | Meta-topic shows software architecture awareness |

**Optional diagrams it supports:**
- ✅ Activity Diagram — task lifecycle workflow (create → assign → work → review → complete)
- ✅ State Diagram — task states (Open → InProgress → Review → Done / Blocked)
- ✅ Component Diagram — TaskModule, PriorityModule, ReportingModule
- ⚠️ Deployment Diagram — could argue multi-layer if you separate "UI" (console) from "service" from "data"

---

## Option 4: Shape Drawing Engine

**Domain:** A drawing tool creates different shapes (Circle, Rectangle, Triangle) and renders them using different drawing strategies (Outline, Filled, Dashed).

**Patterns:**
- **Factory Method** (Creational) — `ShapeFactory` creates `Circle`, `Rectangle`, `Triangle`
- **Strategy** (Behavioral) — `DrawingStrategy` with `OutlineDrawing`, `FilledDrawing`, `DashedDrawing`

**Why it works:** Extremely simple, extremely visual. Shapes are the go-to example in every design patterns textbook. The professor has seen this before — which means expectations are clear.

**Class count:** ~10 (2 interfaces, 3 factories, 3 shapes, 3 strategies, 1 Main)

| Criteria | Score | Notes |
|---|---|---|
| Ease of Implementation | ★★★★★ | Dead simple — shapes just print their properties |
| Ease of Explanation | ★★★★★ | Textbook example, zero ambiguity |
| Pattern Fit | ★★★★★ | Literally the textbook example for Factory Method |
| Mandatory UML Coverage | ★★★★★ | Perfect class hierarchy for UML |
| Optional UML Coverage | ★★☆☆☆ | No meaningful states, no workflow, no components |
| Editability | ★★★★★ | Patterns are completely domain-independent |
| Creativity Points | ★☆☆☆☆ | Lowest — this is the default textbook example |

**Optional diagrams it supports:**
- ⚠️ Activity Diagram — weak (select shape → set properties → draw)
- ❌ State Diagram — shapes don't have lifecycle states
- ❌ Component Diagram — too simple
- ❌ Deployment Diagram — not applicable

---

## Option 5: Smart Home Device Controller

**Domain:** A smart home system manages devices (Light, Thermostat, SecurityCamera). Commands are issued to control them. A central hub coordinates operations.

**Patterns:**
- **Factory Method** (Creational) — `DeviceFactory` creates `Light`, `Thermostat`, `SecurityCamera`
- **Command** (Behavioral) — `TurnOnCommand`, `TurnOffCommand`, `AdjustCommand` with undo support

**Why it works:** IoT is modern and interesting. The Command pattern fits perfectly (remote control issuing commands to devices with undo). Devices have natural states. The system naturally decomposes into components.

**Class count:** ~14 (3 interfaces, 3 device types, 3 factories, 4 commands, 1 RemoteControl/Hub, 1 Main)

| Criteria | Score | Notes |
|---|---|---|
| Ease of Implementation | ★★★★☆ | Command + undo adds slight complexity |
| Ease of Explanation | ★★★★★ | "Alexa, turn on the lights" — everyone gets it |
| Pattern Fit | ★★★★★ | Command pattern was literally designed for this (remote control example) |
| Mandatory UML Coverage | ★★★★★ | Rich class diagram, command sequence is textbook, clear use cases |
| Optional UML Coverage | ★★★★★ | All four optional diagrams fit naturally |
| Editability | ★★★★☆ | Easy to add new devices or commands without touching existing code |
| Creativity Points | ★★★★★ | Modern, interesting, stands out from restaurant/shape projects |

**Optional diagrams it supports:**
- ✅ Activity Diagram — command execution workflow (receive command → validate → execute → log → undo?)
- ✅ State Diagram — device states (Off → On → Adjusting → Error / Standby)
- ✅ Component Diagram — DeviceModule, CommandModule, HubModule, LoggingModule
- ✅ Deployment Diagram — can argue Hub ↔ Devices ↔ User Interface as separate layers

---

## Summary Comparison

| Option | Implementation | Explanation | Pattern Fit | Mandatory UML | Optional UML | Editability | Creativity | **Total /35** |
|---|---|---|---|---|---|---|---|---|
| 1. Order Processing | ★★★★★ | ★★★★★ | ★★★★★ | ★★★★★ | ★★★☆☆ | ★★★★★ | ★★☆☆☆ | **30** |
| 2. Vehicle Fleet | ★★★★☆ | ★★★★★ | ★★★★★ | ★★★★★ | ★★★★☆ | ★★★★☆ | ★★★☆☆ | **30** |
| 3. Task Management | ★★★★☆ | ★★★★★ | ★★★★★ | ★★★★★ | ★★★★★ | ★★★★☆ | ★★★★☆ | **32** |
| 4. Shape Drawing | ★★★★★ | ★★★★★ | ★★★★★ | ★★★★★ | ★★☆☆☆ | ★★★★★ | ★☆☆☆☆ | **27** |
| 5. Smart Home | ★★★★☆ | ★★★★★ | ★★★★★ | ★★★★★ | ★★★★★ | ★★★★☆ | ★★★★★ | **33** |

## Recommendation

**Pick Option 5 (Smart Home) if** you want the highest score potential — it covers ALL optional diagrams, uses the Command pattern (more interesting than Strategy), and scores highest on creativity.

**Pick Option 3 (Task Management) if** you want a safe, high-scoring option that's slightly easier to implement than Smart Home but still covers all optional diagrams.

**Pick Option 1 (Order Processing) if** you want the absolute easiest implementation and don't care about optional diagrams or creativity points.

All options use zero dependencies, are pure Java console apps, and can be swapped without rewriting the pattern structure.
